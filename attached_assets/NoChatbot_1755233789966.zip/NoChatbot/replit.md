# Overview

This repository contains C/N₀ Voidline, an AI-powered audio mastering application with a futuristic console interface. The application features a comprehensive web interface with interactive audio visualization components, terminal-style UI elements, and a cinematic design inspired by sci-fi aesthetics. The project uses a modern full-stack architecture with React for the frontend and Express.js for the backend, featuring real-time audio visualization, particle effects, and a sophisticated dark theme with green accent colors.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
The frontend is built using **React** with **TypeScript** and leverages several key architectural decisions:

- **Component-based Design**: Uses shadcn/ui components for consistent UI patterns, with custom components for audio visualization and terminal interfaces
- **Routing**: Implements client-side routing using Wouter for lightweight navigation
- **State Management**: Uses TanStack React Query for server state management and local React state for component-specific data
- **Styling**: Tailwind CSS with custom CSS variables for the Voidline color palette and theme system
- **Build System**: Vite for fast development and optimized production builds

## Backend Architecture
The backend follows an **Express.js** architecture with the following patterns:

- **Modular Route System**: Routes are organized in a separate `routes.ts` file with a clean registration pattern
- **Storage Abstraction**: Implements an `IStorage` interface with in-memory storage for development, designed to be easily replaceable with database implementations
- **Development Integration**: Custom Vite middleware integration for seamless development experience
- **Error Handling**: Centralized error handling middleware for consistent API responses

## Data Storage Solutions
Currently uses **in-memory storage** for user data with a clean interface pattern:

- **Storage Interface**: `IStorage` interface defines CRUD operations for users
- **Memory Implementation**: `MemStorage` class provides development-friendly data persistence
- **Database Ready**: Drizzle ORM configured for PostgreSQL migration when needed
- **Schema Definition**: Zod-validated database schemas in the shared directory

## Authentication and Authorization
The application has a basic user system foundation:

- **User Schema**: Defines username/password-based user model
- **Session Management**: Uses express-session with PostgreSQL session store configuration
- **Validation**: Zod schemas for input validation and type safety

# External Dependencies

## Database and ORM
- **Drizzle ORM**: Type-safe SQL toolkit with PostgreSQL dialect configuration
- **Neon Database**: Serverless PostgreSQL database service (@neondatabase/serverless)
- **Session Store**: connect-pg-simple for PostgreSQL session management

## UI and Design System
- **shadcn/ui**: Complete component library built on Radix UI primitives
- **Radix UI**: Low-level UI primitives for accessibility and customization
- **Tailwind CSS**: Utility-first CSS framework with custom design tokens
- **Lucide React**: Icon library for consistent iconography

## Frontend Framework and Tools
- **React**: Core UI framework with hooks and modern patterns
- **TypeScript**: Static typing throughout the application
- **Vite**: Fast build tool and development server
- **TanStack React Query**: Server state management and caching
- **Wouter**: Lightweight client-side routing

## Audio and Visualization
- **Three.js Types**: Prepared for 3D audio visualization features
- **Custom Hooks**: Audio visualization logic with React hooks
- **Canvas/WebGL Ready**: Architecture supports advanced graphics rendering

## Development Tools
- **ESBuild**: Fast JavaScript bundler for production builds
- **PostCSS**: CSS processing with Tailwind integration
- **Replit Integration**: Development environment optimizations and tooling