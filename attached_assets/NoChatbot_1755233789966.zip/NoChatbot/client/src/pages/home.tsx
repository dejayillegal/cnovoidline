import VoidlineConsole from "@/components/VoidlineConsole";

export default function Home() {
  return <VoidlineConsole />;
}
