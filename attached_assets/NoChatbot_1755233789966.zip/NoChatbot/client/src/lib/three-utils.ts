// Utility functions for Three.js integration (future use)

export interface Vector3D {
  x: number;
  y: number;
  z: number;
}

export interface ParticleConfig {
  count: number;
  speed: number;
  size: number;
  color: string;
}

export class ParticleSystemManager {
  private particles: Vector3D[] = [];
  private config: ParticleConfig;

  constructor(config: ParticleConfig) {
    this.config = config;
    this.initializeParticles();
  }

  private initializeParticles(): void {
    this.particles = Array.from({ length: this.config.count }, () => ({
      x: Math.random() * window.innerWidth,
      y: Math.random() * window.innerHeight,
      z: Math.random() * 100
    }));
  }

  update(): void {
    this.particles.forEach(particle => {
      particle.y -= this.config.speed;
      particle.x += Math.sin(Date.now() * 0.001 + particle.z) * 0.5;
      
      if (particle.y < -10) {
        particle.y = window.innerHeight + 10;
        particle.x = Math.random() * window.innerWidth;
      }
    });
  }

  getParticles(): Vector3D[] {
    return this.particles;
  }
}

export function createGlowEffect(intensity: number = 1): string {
  return `
    filter: drop-shadow(0 0 ${5 * intensity}px rgba(52, 228, 145, ${0.5 * intensity}))
            drop-shadow(0 0 ${10 * intensity}px rgba(52, 228, 145, ${0.3 * intensity}))
            drop-shadow(0 0 ${20 * intensity}px rgba(52, 228, 145, ${0.1 * intensity}));
  `;
}

export function interpolateColor(color1: string, color2: string, factor: number): string {
  // Simple color interpolation utility
  const hex1 = color1.replace('#', '');
  const hex2 = color2.replace('#', '');
  
  const r1 = parseInt(hex1.substring(0, 2), 16);
  const g1 = parseInt(hex1.substring(2, 4), 16);
  const b1 = parseInt(hex1.substring(4, 6), 16);
  
  const r2 = parseInt(hex2.substring(0, 2), 16);
  const g2 = parseInt(hex2.substring(2, 4), 16);
  const b2 = parseInt(hex2.substring(4, 6), 16);
  
  const r = Math.round(r1 + (r2 - r1) * factor);
  const g = Math.round(g1 + (g2 - g1) * factor);
  const b = Math.round(b1 + (b2 - b1) * factor);
  
  return `#${r.toString(16).padStart(2, '0')}${g.toString(16).padStart(2, '0')}${b.toString(16).padStart(2, '0')}`;
}
