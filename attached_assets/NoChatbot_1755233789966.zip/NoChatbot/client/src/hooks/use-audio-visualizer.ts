import { useState, useEffect } from "react";

interface AudioVisualizerData {
  bars: number[];
  waveform: {
    scale: number;
    brightness: number;
  };
}

export function useAudioVisualizer(barCount: number = 20): AudioVisualizerData {
  const [bars, setBars] = useState<number[]>(() => 
    Array.from({ length: barCount }, () => Math.random() * 80 + 10)
  );
  
  const [waveform, setWaveform] = useState({
    scale: 1,
    brightness: 1
  });

  useEffect(() => {
    const interval = setInterval(() => {
      // Update audio bars with realistic audio-like patterns
      setBars(prev => prev.map((_, index) => {
        // Create some correlation between adjacent bars for realistic look
        const baseHeight = Math.random() * 60 + 20;
        const neighborInfluence = index > 0 ? prev[index - 1] * 0.3 : 0;
        return Math.min(90, Math.max(10, baseHeight + neighborInfluence * 0.1));
      }));

      // Update waveform properties
      setWaveform({
        scale: 1 + Math.random() * 0.2,
        brightness: 1 + Math.random() * 0.5
      });
    }, 150);

    return () => clearInterval(interval);
  }, [barCount]);

  return { bars, waveform };
}
