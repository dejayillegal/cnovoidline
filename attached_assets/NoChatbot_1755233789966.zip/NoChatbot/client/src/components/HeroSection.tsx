import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Play, Upload, Download, Zap, Brain, Users } from "lucide-react";
import TypewriterText from "./TypewriterText";
import AudioVisualizer from "./AudioVisualizer";

export default function HeroSection() {
  const [isUploading, setIsUploading] = useState(false);

  const handleUpload = () => {
    setIsUploading(true);
    setTimeout(() => setIsUploading(false), 3000);
  };

  return (
    <section className="py-20 px-6 relative" data-testid="hero-section">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          
          {/* Left Column - Content */}
          <div className="space-y-8 animate-fade-in-up">
            
            {/* Status Badge */}
            <div className="flex items-center gap-2" data-testid="status-badge">
              <div className="w-2 h-2 bg-void-green rounded-full animate-neural-pulse"></div>
              <Badge className="bg-void-green/20 text-void-green border-void-green/50 font-mono">
                AI ENGINE ONLINE
              </Badge>
            </div>

            {/* Main Heading */}
            <div className="space-y-4">
              <h1 className="text-5xl lg:text-7xl font-bold text-white font-mono leading-tight">
                <TypewriterText 
                  text="Master with"
                  className="block"
                  delay={0}
                  speed={100}
                />
                <span className="text-void-green">
                  <TypewriterText 
                    text="VoidCore™ AI"
                    delay={1200}
                    speed={80}
                  />
                </span>
              </h1>
              <p className="text-xl text-void-gray leading-relaxed max-w-xl">
                Professional audio mastering powered by proprietary neural networks. 
                Real-time processing, zero-knowledge security, enterprise collaboration.
              </p>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-3 gap-6 py-6 border-y border-void-green/20" data-testid="hero-stats">
              <div className="text-center">
                <div className="text-2xl font-bold text-void-green font-mono">500K+</div>
                <div className="text-sm text-void-gray-2">Training Tracks</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-void-green font-mono">&lt;20ms</div>
                <div className="text-sm text-void-gray-2">Latency</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-void-green font-mono">95%</div>
                <div className="text-sm text-void-gray-2">AI Accuracy</div>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="space-y-4">
              <div className="flex flex-col sm:flex-row gap-4" data-testid="hero-actions">
                <Button 
                  className="btn-primary-voidline text-lg px-8 py-4"
                  onClick={handleUpload}
                  disabled={isUploading}
                  data-testid="upload-track-button"
                >
                  {isUploading ? (
                    <>
                      <div className="w-4 h-4 border-2 border-void-dark border-t-transparent rounded-full animate-spin mr-2"></div>
                      Processing...
                    </>
                  ) : (
                    <>
                      <Upload className="w-5 h-5" />
                      Upload Track
                    </>
                  )}
                </Button>
                <Button 
                  variant="outline" 
                  className="btn-secondary-voidline text-lg px-8 py-4"
                  data-testid="demo-button"
                >
                  <Play className="w-5 h-5" />
                  Watch Demo
                </Button>
              </div>
              
              <p className="text-sm text-void-gray-2">
                Free trial • No credit card required • 15 days full access
              </p>
            </div>

            {/* Feature Pills */}
            <div className="flex flex-wrap gap-3" data-testid="feature-pills">
              <div className="flex items-center gap-2 bg-void-dark-2/50 border border-void-green/20 rounded-full px-3 py-1">
                <Brain className="w-3 h-3 text-void-green" />
                <span className="text-xs text-void-gray">VoidCore AI</span>
              </div>
              <div className="flex items-center gap-2 bg-void-dark-2/50 border border-void-green/20 rounded-full px-3 py-1">
                <Zap className="w-3 h-3 text-void-green" />
                <span className="text-xs text-void-gray">Real-time</span>
              </div>
              <div className="flex items-center gap-2 bg-void-dark-2/50 border border-void-green/20 rounded-full px-3 py-1">
                <Users className="w-3 h-3 text-void-green" />
                <span className="text-xs text-void-gray">Collaboration</span>
              </div>
            </div>
          </div>

          {/* Right Column - Interactive Console */}
          <div className="relative animate-fade-in-up delay-200" data-testid="hero-console">
            
            {/* Main Console Window */}
            <div className="terminal relative z-10">
              <div className="terminal-header">
                <div className="terminal-dot bg-void-red"></div>
                <div className="terminal-dot bg-void-yellow"></div>
                <div className="terminal-dot bg-void-green"></div>
                <span className="text-void-gray-2 ml-4 font-mono">voidcore@mastering-engine</span>
                
                {/* Processing Indicator */}
                <div className="ml-auto flex items-center gap-2">
                  <div className="w-2 h-2 bg-void-green rounded-full animate-neural-pulse"></div>
                  <span className="text-xs text-void-green font-mono">PROCESSING</span>
                </div>
              </div>
              
              <div className="terminal-content space-y-6">
                {/* Command Input */}
                <div className="space-y-2">
                  <div className="font-mono text-lg">
                    <span className="text-void-green">$ </span>
                    <TypewriterText 
                      text="voidcore --analyze track.wav"
                      delay={500}
                      speed={50}
                    />
                  </div>
                </div>

                {/* AI Analysis Output */}
                <div className="space-y-2 text-sm font-mono">
                  <TypewriterText 
                    text="[AI] Initializing VoidCore neural engine..."
                    className="text-void-green"
                    delay={2000}
                    speed={30}
                  />
                  <TypewriterText 
                    text="[AI] Genre detected: Electronic/Synthwave (96.4% confidence)"
                    className="text-void-gray"
                    delay={3000}
                    speed={25}
                  />
                  <TypewriterText 
                    text="[AI] Dynamic range: 8.2 dB • Peak: -2.1 dBFS • LUFS: -16.8"
                    className="text-void-gray"
                    delay={4200}
                    speed={25}
                  />
                  <TypewriterText 
                    text="[AI] Optimal target: -14.2 LUFS for streaming platforms"
                    className="text-void-blue"
                    delay={5500}
                    speed={25}
                  />
                  <TypewriterText 
                    text="[AI] EQ curve generated • Compression applied • Ready for export"
                    className="text-void-green"
                    delay={6800}
                    speed={25}
                  />
                </div>

                {/* Audio Visualizer */}
                <div className="pt-4 border-t border-void-green/20">
                  <AudioVisualizer compact />
                </div>

                {/* Processing Stats */}
                <div className="grid grid-cols-2 gap-4 text-xs font-mono">
                  <div className="space-y-1">
                    <div className="flex justify-between">
                      <span className="text-void-gray-2">processing</span>
                      <span className="text-void-green">14ms</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-void-gray-2">quality</span>
                      <span className="text-void-green">96kHz/24bit</span>
                    </div>
                  </div>
                  <div className="space-y-1">
                    <div className="flex justify-between">
                      <span className="text-void-gray-2">confidence</span>
                      <span className="text-void-green">98.7%</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-void-gray-2">output</span>
                      <span className="text-void-green">ready</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Floating Elements */}
            <div className="absolute -top-4 -right-4 w-16 h-16 border-2 border-void-green/30 rounded-full animate-neural-pulse"></div>
            <div className="absolute -bottom-4 -left-4 w-12 h-12 border-2 border-void-blue/30 rounded-full animate-neural-pulse" style={{ animationDelay: '1s' }}></div>
            
            {/* Data Flow Lines */}
            <div className="absolute top-1/2 -right-8 w-20 h-px bg-gradient-to-r from-void-green to-transparent animate-data-flow"></div>
            <div className="absolute bottom-1/4 -left-8 w-16 h-px bg-gradient-to-l from-void-blue to-transparent animate-data-flow" style={{ animationDelay: '1.5s' }}></div>
          </div>
        </div>

        {/* Trust Indicators */}
        <div className="mt-20 text-center animate-fade-in-up delay-400" data-testid="trust-indicators">
          <p className="text-sm text-void-gray-2 mb-6">Trusted by producers and labels worldwide</p>
          <div className="flex flex-wrap justify-center items-center gap-8 opacity-60">
            <div className="text-void-gray font-mono text-sm">Universal Music</div>
            <div className="text-void-gray font-mono text-sm">Sony Music</div>
            <div className="text-void-gray font-mono text-sm">Warner Records</div>
            <div className="text-void-gray font-mono text-sm">Deadmau5</div>
            <div className="text-void-gray font-mono text-sm">Skrillex</div>
          </div>
        </div>
      </div>
    </section>
  );
}