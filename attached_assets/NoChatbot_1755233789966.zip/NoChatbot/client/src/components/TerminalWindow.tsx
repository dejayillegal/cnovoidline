import { ReactNode } from "react";

interface TerminalWindowProps {
  title?: string;
  children: ReactNode;
}

export default function TerminalWindow({ title = "terminal", children }: TerminalWindowProps) {
  return (
    <div className="terminal" data-testid="terminal-window">
      <div className="terminal-header" data-testid="terminal-header">
        <div className="terminal-dot bg-void-red" data-testid="terminal-dot-red"></div>
        <div className="terminal-dot bg-void-yellow" data-testid="terminal-dot-yellow"></div>
        <div className="terminal-dot bg-void-green" data-testid="terminal-dot-green"></div>
        <span className="text-void-gray-2 ml-4" data-testid="terminal-title">{title}</span>
      </div>
      <div className="terminal-content" data-testid="terminal-content">
        {children}
      </div>
    </div>
  );
}
