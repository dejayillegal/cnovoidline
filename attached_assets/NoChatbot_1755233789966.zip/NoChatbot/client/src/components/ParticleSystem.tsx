import { useEffect, useRef } from "react";

export default function ParticleSystem() {
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const createParticles = () => {
      const particleCount = 50;
      
      for (let i = 0; i < particleCount; i++) {
        const particle = document.createElement('div');
        particle.className = 'absolute w-0.5 h-0.5 bg-void-green rounded-full opacity-60';
        particle.style.left = Math.random() * 100 + '%';
        particle.style.animation = `particleFloat ${Math.random() * 10 + 10}s linear infinite`;
        particle.style.animationDelay = Math.random() * 15 + 's';
        
        // Add custom keyframes for particle movement
        const keyframes = `
          @keyframes particleFloat {
            0% {
              transform: translateY(100vh) translateX(0px);
              opacity: 0;
            }
            10% {
              opacity: 1;
            }
            90% {
              opacity: 1;
            }
            100% {
              transform: translateY(-100px) translateX(50px);
              opacity: 0;
            }
          }
        `;
        
        if (!document.querySelector('#particle-keyframes')) {
          const style = document.createElement('style');
          style.id = 'particle-keyframes';
          style.textContent = keyframes;
          document.head.appendChild(style);
        }
        
        container.appendChild(particle);
      }
    };

    createParticles();

    return () => {
      if (container) {
        container.innerHTML = '';
      }
    };
  }, []);

  return (
    <div 
      ref={containerRef}
      className="fixed top-0 left-0 w-full h-full z-[-1] pointer-events-none"
      data-testid="particle-system"
    />
  );
}
