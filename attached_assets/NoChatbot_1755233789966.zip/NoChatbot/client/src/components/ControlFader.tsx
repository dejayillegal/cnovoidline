import { useState, useRef, useEffect } from "react";

interface ControlFaderProps {
  label: string;
  initialValue?: number;
  unit?: string;
  onChange?: (value: number) => void;
}

export default function ControlFader({ 
  label, 
  initialValue = 50, 
  unit = "dB",
  onChange 
}: ControlFaderProps) {
  const [value, setValue] = useState(initialValue);
  const [isDragging, setIsDragging] = useState(false);
  const faderRef = useRef<HTMLDivElement>(null);

  const handleMouseDown = (e: React.MouseEvent) => {
    setIsDragging(true);
    e.preventDefault();
  };

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (!isDragging || !faderRef.current) return;

      const rect = faderRef.current.getBoundingClientRect();
      const y = e.clientY - rect.top;
      const percentage = Math.max(0, Math.min(100, (y / rect.height) * 100));
      const newValue = 100 - percentage; // Invert because top is max
      
      setValue(newValue);
      onChange?.(newValue);
    };

    const handleMouseUp = () => {
      setIsDragging(false);
    };

    if (isDragging) {
      document.addEventListener('mousemove', handleMouseMove);
      document.addEventListener('mouseup', handleMouseUp);
    }

    return () => {
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleMouseUp);
    };
  }, [isDragging, onChange]);

  const displayValue = ((value - 50) * 0.1).toFixed(1);

  return (
    <div className="text-center" data-testid={`fader-${label.toLowerCase().replace(' ', '-')}`}>
      <div 
        ref={faderRef}
        className="control-fader mx-auto mb-3"
        data-testid={`fader-track-${label.toLowerCase().replace(' ', '-')}`}
      >
        <div 
          className={`fader-handle ${isDragging ? 'cursor-grabbing' : 'cursor-grab'}`}
          style={{ top: `${100 - value}%` }}
          onMouseDown={handleMouseDown}
          data-testid={`fader-handle-${label.toLowerCase().replace(' ', '-')}`}
        />
      </div>
      <label className="text-sm text-void-gray-2" data-testid={`fader-label-${label.toLowerCase().replace(' ', '-')}`}>
        {label}
      </label>
      <div className="text-void-green font-mono text-xs mt-1" data-testid={`fader-value-${label.toLowerCase().replace(' ', '-')}`}>
        {Number(displayValue) > 0 ? '+' : ''}{displayValue}{unit}
      </div>
    </div>
  );
}
