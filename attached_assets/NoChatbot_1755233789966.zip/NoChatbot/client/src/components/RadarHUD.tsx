import { useEffect, useRef } from "react";

export default function RadarHUD() {
  const sweepRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Add rotation animation to the sweep
    if (sweepRef.current) {
      sweepRef.current.style.animation = 'spin 6s linear infinite';
    }
  }, []);

  return (
    <div className="relative w-72 h-72 mx-auto" data-testid="radar-hud">
      {/* Radar Circles */}
      <div className="absolute inset-0 border-2 border-void-green/20 rounded-full" data-testid="radar-circle-outer" />
      <div className="absolute inset-8 border-2 border-void-green/20 rounded-full" data-testid="radar-circle-middle" />
      <div className="absolute inset-16 border-2 border-void-green/20 rounded-full" data-testid="radar-circle-inner" />
      
      {/* Crosshairs */}
      <div className="absolute left-1/2 top-0 w-px h-full bg-void-green/20 transform -translate-x-px" data-testid="radar-crosshair-vertical" />
      <div className="absolute top-1/2 left-0 h-px w-full bg-void-green/20 transform -translate-y-px" data-testid="radar-crosshair-horizontal" />
      
      {/* Sweep */}
      <div 
        ref={sweepRef}
        className="absolute inset-0 opacity-65"
        data-testid="radar-sweep"
      >
        <div 
          className="w-full h-full rounded-full relative overflow-hidden"
          style={{
            background: 'conic-gradient(from 0deg, transparent 300deg, rgba(52, 228, 145, 0.3) 360deg)'
          }}
        />
      </div>
      
      {/* Center Dot */}
      <div className="absolute top-1/2 left-1/2 w-2 h-2 bg-void-green rounded-full transform -translate-x-1 -translate-y-1 animate-neural-pulse" data-testid="radar-center" />
      
      {/* Blips */}
      <div className="absolute top-1/4 right-1/3 w-1 h-1 bg-void-green rounded-full animate-neural-pulse" data-testid="radar-blip-1" />
      <div className="absolute bottom-1/3 left-1/4 w-1 h-1 bg-void-green rounded-full animate-neural-pulse" style={{ animationDelay: '1s' }} data-testid="radar-blip-2" />
      <div className="absolute top-2/3 right-1/4 w-1 h-1 bg-void-green rounded-full animate-neural-pulse" style={{ animationDelay: '2s' }} data-testid="radar-blip-3" />
    </div>
  );
}
