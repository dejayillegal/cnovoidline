import { useState, useEffect } from "react";

interface Stat {
  label: string;
  value: string;
  unit?: string;
}

export default function SystemStats() {
  const [stats, setStats] = useState<Stat[]>([
    { label: "integrity", value: "98", unit: "%" },
    { label: "latency", value: "18", unit: " ms" },
    { label: "throughput", value: "1.2", unit: " Gb/s" }
  ]);

  useEffect(() => {
    const interval = setInterval(() => {
      setStats(prev => prev.map(stat => {
        switch (stat.label) {
          case "integrity":
            return { ...stat, value: (Math.random() > 0.5 ? "99" : "98") };
          case "latency":
            return { ...stat, value: String(Math.floor(Math.random() * 10) + 16) };
          case "throughput":
            return { ...stat, value: (1.0 + Math.random() * 0.5).toFixed(1) };
          default:
            return stat;
        }
      }));
    }, 2000);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="space-y-3" data-testid="system-stats">
      {stats.map((stat, index) => (
        <div 
          key={stat.label}
          className="bg-void-dark-2 border border-void-green/20 rounded-lg p-3 flex justify-between items-center"
          data-testid={`stat-${stat.label}`}
        >
          <span className="text-void-gray-2 text-sm">{stat.label}</span>
          <span className="text-void-green font-mono font-bold">
            {stat.value}{stat.unit}
          </span>
        </div>
      ))}
    </div>
  );
}
