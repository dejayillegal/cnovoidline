import { useEffect } from "react";
import BackgroundEffects from "./BackgroundEffects";
import TerminalWindow from "./TerminalWindow";
import SystemStats from "./SystemStats";
import AudioVisualizer from "./AudioVisualizer";
import RadarHUD from "./RadarHUD";
import ControlFader from "./ControlFader";
import TypewriterText from "./TypewriterText";
import { Button } from "@/components/ui/button";
import { Play, Upload, Satellite, Cpu, Zap } from "lucide-react";

export default function VoidlineConsole() {
  useEffect(() => {
    // Set dark mode
    document.documentElement.classList.add('dark');
  }, []);

  return (
    <div className="min-h-screen bg-void-dark text-void-gray font-mono relative overflow-x-hidden">
      {/* Background Effects */}
      <BackgroundEffects />
      
      {/* Header */}
      <header className="relative z-50 p-6" data-testid="header-main">
        <div className="glass-panel p-4 max-w-7xl mx-auto">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              {/* Brand Logo */}
              <div className="text-void-green text-2xl font-bold" data-testid="brand-logo">
                <svg width="60" height="60" viewBox="0 0 1080 1080" className="w-8 h-8">
                  <g fill="currentColor" transform="matrix(1,0,0,1.0021480321884155,0,0)">
                    <path d="M 347.931 299.357 L 600 299.357 L 500 399.143 L 327.098 399.143 L 324.707 754.688 L 500 758.542 L 600 867.385 C 608.483 871.506 780.117 868.059 780.117 868.059 L 780.797 898.071 C 780.797 899.511 263.672 898.071 263.672 898.071 L 98.438 744.141 L 100 540.235 L 347.931 299.357 Z"/>
                    <path d="M 800 299.357 L 863.672 299.357 L 965.625 399.609 L 965.625 530.859 L 800 530.877 L 800 299.357 Z"/>
                    <path d="M 1000 299.357 L 1062.97 298.7 C 1063.89 299.026 1064 374.527 1062.49 374.294 L 1000 374.817 L 1000 299.357 Z"/>
                    <path d="M 1000.13 546.094 L 1080.4 546.048 L 1079.72 714.844 L 1000 715.642 L 1000.13 546.094 Z"/>
                    <path d="M 700.406 546.094 L 800 545.126 L 800 651.563 L 700.406 651.563 L 700.406 546.094 Z"/>
                    <path d="M 871.875 828.682 C 871.875 828.682 969.424 756.221 967.08 763.057 L 965.625 898.071 L 871.158 898.071 L 871.875 828.682 Z"/>
                  </g>
                </svg>
              </div>
              <div>
                <h1 className="text-xl font-bold text-white" data-testid="header-title">[./C/N₀_Voidline]</h1>
                <p className="text-sm text-void-gray-2" data-testid="header-subtitle">ai-mastering-core</p>
              </div>
            </div>
            
            <nav className="hidden md:flex items-center gap-6 text-sm" data-testid="nav-main">
              <a href="#" className="text-void-green hover:text-white transition-colors" data-testid="nav-home">/home</a>
              <a href="#" className="text-void-gray-2 hover:text-white transition-colors" data-testid="nav-features">/features</a>
              <a href="#" className="text-void-gray-2 hover:text-white transition-colors" data-testid="nav-pricing">/pricing</a>
              <a href="#" className="text-void-gray-2 hover:text-white transition-colors" data-testid="nav-docs">/docs</a>
              <a href="#" className="text-void-gray-2 hover:text-white transition-colors" data-testid="nav-logs">/logs</a>
            </nav>
            
            <div className="flex items-center gap-4">
              <Button variant="outline" size="sm" className="hidden lg:block text-void-green border-void-green hover:bg-void-green hover:text-void-dark" data-testid="button-login">
                Login
              </Button>
              <div className="flex gap-2" data-testid="terminal-dots">
                <div className="w-3 h-3 rounded-full bg-void-red"></div>
                <div className="w-3 h-3 rounded-full bg-void-yellow"></div>
                <div className="w-3 h-3 rounded-full bg-void-green"></div>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="relative z-40 px-6 py-12" data-testid="main-content">
        <div className="max-w-7xl mx-auto">
          
          {/* Hero Terminal */}
          <section className="mb-16 animate-fade-in-up" data-testid="hero-terminal">
            <TerminalWindow title="voidline@console — bash">
              <div className="space-y-6">
                <h1 className="text-3xl lg:text-5xl font-bold text-white mb-6">
                  <span className="text-void-green">$ </span>
                  <TypewriterText text="./ai-mastering-core --init" className="typewriter" />
                </h1>
                <p className="text-lg text-void-gray leading-relaxed" data-testid="hero-description">
                  Welcome, producer. Advanced AI is calibrated and ready to analyze your audio. 
                  Upload a track to begin mastering and unlock its full sonic potential.
                </p>
                
                <div className="flex flex-col sm:flex-row gap-4 mb-8" data-testid="hero-buttons">
                  <Button className="btn-primary-voidline" data-testid="button-start-mastering">
                    <Play className="w-4 h-4" />
                    Start Mastering
                  </Button>
                  <Button variant="outline" className="btn-secondary-voidline" data-testid="button-upload-audio">
                    <Upload className="w-4 h-4" />
                    Upload Audio File...
                  </Button>
                </div>
                
                <div className="border-t border-void-green/20 pt-6" data-testid="system-feed">
                  <p className="text-void-gray-2 mb-2"><span className="text-void-green">$ </span>Live System Feed:</p>
                  <div className="space-y-1 text-sm font-mono">
                    <TypewriterText 
                      text="[STATUS] AI core initialized and stable." 
                      className="text-void-gray" 
                      delay={0}
                      speed={30}
                    />
                    <TypewriterText 
                      text="[LINK] Neural connection nominal. Channels synchronized." 
                      className="text-void-gray" 
                      delay={800}
                      speed={35}
                    />
                    <TypewriterText 
                      text="[ALERT] Solar flare activity detected — uplink integrity at 98%." 
                      className="text-void-yellow" 
                      delay={2400}
                      speed={40}
                    />
                    <TypewriterText 
                      text="[READY] System awaiting your command." 
                      className="text-void-gray" 
                      delay={4500}
                      speed={25}
                    />
                  </div>
                </div>
              </div>
            </TerminalWindow>
          </section>

          {/* Console Grid Layout */}
          <section className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-16" data-testid="console-grid">
            
            {/* Left Column - Process Cards */}
            <div className="lg:col-span-2 space-y-6">
              
              {/* Row 1: Main Control Panel */}
              <div className="glass-panel p-6 animate-fade-in-up delay-100" data-testid="main-control-panel">
                <div className="flex items-center justify-between mb-4 pb-4 border-b border-void-green/20">
                  <h3 className="font-bold text-void-green">Analysis Engine</h3>
                  <span className="text-xs text-void-gray-2">CORE: DECONSTRUCT</span>
                </div>
                <h4 className="text-xl font-semibold text-white mb-3">Deep Signal Deconstruction</h4>
                <p className="text-void-gray-2 mb-6 leading-relaxed">
                  Dynamics, frequency, stereo image.
                </p>
                <AudioVisualizer />
              </div>

              {/* Row 2: Phase Overview */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                
                {/* Phase 1 */}
                <div className="glass-panel p-6 animate-fade-in-up delay-200" data-testid="phase-analysis">
                  <div className="text-center mb-4">
                    <div className="text-void-green text-sm font-bold mb-2">Core: Deconstruct</div>
                    <h4 className="text-lg font-semibold text-white">Analysis</h4>
                  </div>
                  <AudioVisualizer compact />
                  <p className="text-xs text-void-gray-2 mt-4 text-center">
                    Dynamics, frequency, stereo image.
                  </p>
                </div>

                {/* Phase 2 */}
                <div className="glass-panel p-6 animate-fade-in-up delay-300" data-testid="phase-enhancement">
                  <div className="text-center mb-4">
                    <div className="text-void-green text-sm font-bold mb-2">Core: Rebuild</div>
                    <h4 className="text-lg font-semibold text-white">Enhancement</h4>
                  </div>
                  <div className="hologram p-4 rounded-lg mb-4 h-16 relative overflow-hidden">
                    <div className="flex justify-center items-center h-full">
                      <div className="w-6 h-6 rounded-full border-2 border-void-green animate-neural-pulse"></div>
                      <div className="absolute bottom-2 left-2 w-14 h-2 bg-void-green rounded"></div>
                      <div className="absolute bottom-0 left-0 w-20 h-2 bg-void-green rounded"></div>
                    </div>
                  </div>
                  <p className="text-xs text-void-gray-2 text-center">
                    EQ, dynamics, clarity.
                  </p>
                </div>

                {/* Phase 3 */}
                <div className="glass-panel p-6 animate-fade-in-up delay-400" data-testid="phase-transmission">
                  <div className="text-center mb-4">
                    <div className="text-void-green text-sm font-bold mb-2">Core: Transmit</div>
                    <h4 className="text-lg font-semibold text-white">Transmission</h4>
                  </div>
                  <div className="bg-black/50 p-3 rounded-lg mb-4 h-16 relative overflow-hidden border border-void-green/20">
                    <div className="w-3 h-3 rounded-full bg-void-yellow absolute left-3 top-1/2 transform -translate-y-1/2"></div>
                    <div className="absolute left-8 top-1/2 transform -translate-y-1/2 w-16 h-2 bg-void-green rounded">
                      <div className="h-full bg-gradient-to-r from-void-green to-transparent rounded animate-data-flow"></div>
                    </div>
                  </div>
                  <p className="text-xs text-void-gray-2 text-center">
                    Robust, clean output.
                  </p>
                </div>
              </div>

              {/* Row 3: Activity Log */}
              <div className="glass-panel p-6 animate-fade-in-up delay-500" data-testid="activity-log">
                <h3 className="text-lg font-bold text-white mb-4">activity log</h3>
                <div className="space-y-3 font-mono text-sm">
                  <TypewriterText 
                    text="[10:24:03] Loader: Scanned 2,184 frames • peak -2.3 dBFS • LUFS -14.2 • crest 10.8 dB" 
                    className="text-void-gray" 
                    delay={0}
                    speed={15}
                  />
                  <TypewriterText 
                    text="[10:24:06] Stage: Transient shaping applied • SNR +3.1 dB • stereo spread +6%" 
                    className="text-void-gray" 
                    delay={1200}
                    speed={15}
                  />
                  <TypewriterText 
                    text="[10:24:10] Output: True-peak limiter armed • ceiling -0.9 dBTP • dithering TPDF 16-bit" 
                    className="text-void-gray" 
                    delay={2400}
                    speed={15}
                  />
                </div>
                
                <div className="grid grid-cols-2 gap-8 mt-6 text-sm font-mono">
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span className="text-void-gray-2">preset</span>
                      <span className="text-white">Cinematic Wide v3</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-void-gray-2">target</span>
                      <span className="text-white">-14 LUFS, -1 dBTP</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-void-gray-2">export</span>
                      <span className="text-white">24-bit WAV, 48 kHz</span>
                    </div>
                  </div>
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span className="text-void-gray-2">mid/side</span>
                      <span className="text-white">balanced</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-void-gray-2">dynamics</span>
                      <span className="text-white">gentle</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-void-gray-2">enhance</span>
                      <span className="text-white">+8%</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Right Column - System Monitoring */}
            <div className="space-y-6">
              
              {/* System Stats */}
              <div className="glass-panel p-4 animate-fade-in-up delay-100" data-testid="system-stats">
                <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
                  <Cpu className="w-4 h-4 text-void-green" />
                  System Stats
                </h3>
                <SystemStats />
              </div>

              {/* Radar HUD */}
              <div className="glass-panel p-4 animate-fade-in-up delay-200" data-testid="radar-hud">
                <div className="text-center">
                  <RadarHUD />
                  <p className="text-sm text-void-gray-2 mt-2">Acquisition</p>
                </div>
              </div>

              {/* Control Faders */}
              <div className="glass-panel p-4 animate-fade-in-up delay-300" data-testid="transfer-control">
                <h3 className="text-sm text-void-gray-2 mb-4">transfer</h3>
                <div className="bg-black/50 border border-void-green/20 rounded-lg p-2 mb-4 relative overflow-hidden h-6">
                  <div className="h-full bg-void-green rounded-md animate-data-flow" style={{ width: '70%' }}></div>
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="w-full h-px bg-void-green/30"></div>
                  </div>
                </div>
                <div className="text-right text-void-green font-mono text-lg font-bold">100%</div>
                <div className="flex justify-between mt-3 text-xs text-void-gray-2">
                  <span>|</span>
                  <span>|</span>
                  <span>|</span>
                  <span>|</span>
                </div>
              </div>

              {/* Signal Strength */}
              <div className="glass-panel p-4 animate-fade-in-up delay-400" data-testid="signal-strength">
                <h3 className="text-sm text-void-gray-2 mb-2">signal strength</h3>
                <div className="text-6xl font-bold text-white mb-4">93</div>
                <div className="flex items-end justify-start gap-1 h-16 mb-4">
                  <div className="w-3 bg-void-green rounded-sm animate-audio-bar-dance" style={{ height: '60%', animationDelay: '0.1s' }}></div>
                  <div className="w-3 bg-void-green rounded-sm animate-audio-bar-dance" style={{ height: '80%', animationDelay: '0.2s' }}></div>
                  <div className="w-3 bg-void-green rounded-sm animate-audio-bar-dance" style={{ height: '70%', animationDelay: '0.3s' }}></div>
                  <div className="w-3 bg-void-green rounded-sm animate-audio-bar-dance" style={{ height: '95%', animationDelay: '0.4s' }}></div>
                </div>
                <div className="flex gap-2">
                  <div className="bg-void-dark-2 border border-void-green/20 rounded-lg px-4 py-2 text-xs">
                    <span className="text-void-green">stable</span>
                  </div>
                  <div className="bg-void-dark-2 border border-void-green/20 rounded-lg px-4 py-2 text-xs">
                    <span className="text-white">priority: high</span>
                  </div>
                </div>
              </div>
            </div>
          </section>

          {/* Pricing Section */}
          <section className="mb-16" data-testid="pricing-section">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold text-white mb-4">
                <span className="text-void-green">$ </span>Transmission Pricing
              </h2>
              <p className="text-void-gray-2 max-w-2xl mx-auto">
                Choose your mastering tier based on your production needs and signal complexity requirements.
              </p>
            </div>
            
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8" data-testid="pricing-cards">
              
              {/* Payload Tier */}
              <div className="pricing-card animate-fade-in-up delay-100" data-testid="pricing-payload">
                <div className="text-center">
                  <h3 className="text-xl font-bold text-white mb-2">Payload</h3>
                  <p className="text-void-gray-2 text-sm mb-6">15 Day Free Trial</p>
                  <div className="text-4xl font-bold text-white mb-8">Free</div>
                </div>
                
                <ul className="space-y-3 mb-8 text-sm">
                  <li className="flex items-center gap-3">
                    <Zap className="w-4 h-4 text-void-green" />
                    <span>3 AI Masters</span>
                  </li>
                  <li className="flex items-center gap-3">
                    <Zap className="w-4 h-4 text-void-green" />
                    <span>WAV & MP3 Exports</span>
                  </li>
                  <li className="flex items-center gap-3">
                    <Zap className="w-4 h-4 text-void-green" />
                    <span>Standard Delivery</span>
                  </li>
                </ul>
                
                <Button variant="outline" className="w-full btn-secondary-voidline" data-testid="button-start-trial">
                  Start Trial
                </Button>
              </div>

              {/* Orbital Pack */}
              <div className="pricing-card featured animate-fade-in-up delay-200 relative" data-testid="pricing-orbital">
                <div className="absolute top-4 right-4 bg-void-green text-void-dark px-2 py-1 text-xs font-bold rounded">
                  MOST POPULAR
                </div>
                <div className="text-center">
                  <h3 className="text-xl font-bold text-white mb-2">Orbital Pack</h3>
                  <p className="text-void-gray-2 text-sm mb-2">Ideal for EPs and albums, providing better value.</p>
                  <div className="text-4xl font-bold text-white mb-2">₹ 599</div>
                  <p className="text-void-gray-2 text-sm mb-8">/ month</p>
                </div>
                
                <ul className="space-y-3 mb-8 text-sm">
                  <li className="flex items-center gap-3">
                    <Zap className="w-4 h-4 text-void-green" />
                    <span>15 AI Masters / month</span>
                  </li>
                  <li className="flex items-center gap-3">
                    <Zap className="w-4 h-4 text-void-green" />
                    <span>All Formats (WAV, MP3, FLAC)</span>
                  </li>
                  <li className="flex items-center gap-3">
                    <Zap className="w-4 h-4 text-void-green" />
                    <span>Priority Queue</span>
                  </li>
                  <li className="flex items-center gap-3">
                    <Zap className="w-4 h-4 text-void-green" />
                    <span>Reference Tracks</span>
                  </li>
                </ul>
                
                <Button className="w-full btn-primary-voidline" data-testid="button-select-orbital">
                  Select Plan
                </Button>
              </div>

              {/* Voidline Unlimited */}
              <div className="pricing-card animate-fade-in-up delay-300" data-testid="pricing-unlimited">
                <div className="text-center">
                  <h3 className="text-xl font-bold text-white mb-2">Voidline Unlimited</h3>
                  <p className="text-void-gray-2 text-sm mb-2">For the prolific producer and professional studios.</p>
                  <div className="text-4xl font-bold text-white mb-2">₹ 999</div>
                  <p className="text-void-gray-2 text-sm mb-8">/ year</p>
                </div>
                
                <ul className="space-y-3 mb-8 text-sm">
                  <li className="flex items-center gap-3">
                    <Zap className="w-4 h-4 text-void-green" />
                    <span>Unlimited AI Masters</span>
                  </li>
                  <li className="flex items-center gap-3">
                    <Zap className="w-4 h-4 text-void-green" />
                    <span>All Formats & Features</span>
                  </li>
                  <li className="flex items-center gap-3">
                    <Zap className="w-4 h-4 text-void-green" />
                    <span>Highest Priority Access</span>
                  </li>
                  <li className="flex items-center gap-3">
                    <Zap className="w-4 h-4 text-void-green" />
                    <span>Dedicated Support Channel</span>
                  </li>
                </ul>
                
                <Button variant="outline" className="w-full btn-secondary-voidline" data-testid="button-select-unlimited">
                  Select Plan
                </Button>
              </div>
            </div>
          </section>

        </div>
      </main>

      {/* Footer */}
      <footer className="relative z-40 px-6 py-8 border-t border-void-green/20" data-testid="footer-main">
        <div className="max-w-7xl mx-auto text-center">
          <p className="text-void-gray-2 font-mono text-sm">
            Designed & Developed by [AUDIO:STATION:2042] 
            <span className="mx-4">|</span>
            <a href="#" className="text-void-green hover:text-white transition-colors" data-testid="link-privacy">Privacy Portal</a>
            <span className="mx-4">|</span>
            <a href="#" className="text-void-green hover:text-white transition-colors" data-testid="link-terms">Terms of Service</a>
          </p>
        </div>
      </footer>
    </div>
  );
}
