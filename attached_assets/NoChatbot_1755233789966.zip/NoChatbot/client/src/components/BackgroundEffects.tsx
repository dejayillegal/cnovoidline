import { useEffect, useRef } from "react";
import ParticleSystem from "./ParticleSystem";

export default function BackgroundEffects() {
  const neuralNetworkRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Create neural network nodes and connections
    const container = neuralNetworkRef.current;
    if (!container) return;

    const createNeuralNetwork = () => {
      const nodeCount = 20;
      
      // Create nodes
      for (let i = 0; i < nodeCount; i++) {
        const node = document.createElement('div');
        node.className = 'absolute w-1 h-1 bg-void-green rounded-full animate-neural-pulse';
        node.style.left = Math.random() * 100 + '%';
        node.style.top = Math.random() * 100 + '%';
        node.style.animationDelay = Math.random() * 3 + 's';
        node.style.opacity = '0.1';
        container.appendChild(node);
      }
      
      // Create connections
      for (let i = 0; i < nodeCount / 2; i++) {
        const connection = document.createElement('div');
        connection.className = 'absolute h-px bg-gradient-to-r from-transparent via-void-green to-transparent animate-data-flow';
        connection.style.left = Math.random() * 90 + '%';
        connection.style.top = Math.random() * 90 + '%';
        connection.style.width = Math.random() * 100 + 50 + 'px';
        connection.style.transform = 'rotate(' + (Math.random() * 360) + 'deg)';
        connection.style.animationDelay = Math.random() * 2 + 's';
        connection.style.opacity = '0.1';
        container.appendChild(connection);
      }
    };

    createNeuralNetwork();

    return () => {
      if (container) {
        container.innerHTML = '';
      }
    };
  }, []);

  return (
    <>
      {/* Matrix Background */}
      <div className="bg-matrix" />
      
      {/* Grid Overlay */}
      <div className="grid-overlay" />
      
      {/* Scanlines */}
      <div className="scanlines" />
      
      {/* Particle System */}
      <ParticleSystem />
      
      {/* Neural Network Background */}
      <div 
        ref={neuralNetworkRef}
        className="fixed top-0 left-0 w-full h-full z-[-2] opacity-10 pointer-events-none"
        data-testid="neural-network"
      />
    </>
  );
}
