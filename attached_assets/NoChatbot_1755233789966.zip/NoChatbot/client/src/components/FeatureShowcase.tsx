import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Brain, 
  Zap, 
  Users, 
  Shield, 
  Cpu, 
  Activity,
  Eye,
  Mic,
  Globe,
  Lock
} from "lucide-react";
import AudioVisualizer from "./AudioVisualizer";
import TypewriterText from "./TypewriterText";

interface Feature {
  id: string;
  title: string;
  description: string;
  icon: React.ReactNode;
  category: string;
  demo?: React.ReactNode;
  badge?: string;
}

const features: Feature[] = [
  {
    id: "voidcore-ai",
    title: "VoidCore™ Neural Engine",
    description: "Proprietary transformer-based AI trained on 500,000+ professionally mastered tracks. Achieves 95% genre classification accuracy and LUFS prediction within ±0.2 dB.",
    icon: <Brain className="w-6 h-6" />,
    category: "AI Engine",
    badge: "PROPRIETARY",
    demo: (
      <div className="bg-black/50 p-4 rounded-lg border border-void-green/20">
        <div className="font-mono text-xs space-y-2">
          <TypewriterText text="[AI] Analyzing spectral content..." className="text-void-green" delay={0} speed={30} />
          <TypewriterText text="[AI] Genre detected: Electronic/Synthwave (96% confidence)" className="text-void-gray" delay={1000} speed={20} />
          <TypewriterText text="[AI] Optimal LUFS target: -14.2 dB" className="text-void-gray" delay={2000} speed={20} />
          <TypewriterText text="[AI] EQ curve optimized for streaming platforms" className="text-void-blue" delay={3000} speed={20} />
        </div>
      </div>
    )
  },
  {
    id: "realtime-processing",
    title: "Sub-20ms Latency Processing",
    description: "WebAssembly-optimized DSP chain delivers professional mastering in real-time. No upload/download workflow required.",
    icon: <Zap className="w-6 h-6" />,
    category: "Performance",
    demo: <AudioVisualizer compact />
  },
  {
    id: "collaboration",
    title: "Real-time Collaboration",
    description: "Multi-user editing with version control, timestamped comments, and conflict resolution. Built-in client portal for seamless feedback loops.",
    icon: <Users className="w-6 h-6" />,
    category: "Workflow",
    demo: (
      <div className="space-y-2">
        <div className="flex items-center gap-2 text-xs">
          <div className="w-2 h-2 bg-void-green rounded-full animate-neural-pulse"></div>
          <span className="text-void-gray">Sarah (Producer) - Online</span>
        </div>
        <div className="flex items-center gap-2 text-xs">
          <div className="w-2 h-2 bg-void-blue rounded-full animate-neural-pulse"></div>
          <span className="text-void-gray">Mike (Engineer) - Editing EQ</span>
        </div>
        <div className="flex items-center gap-2 text-xs">
          <div className="w-2 h-2 bg-void-yellow rounded-full animate-neural-pulse"></div>
          <span className="text-void-gray">Client - Reviewing changes</span>
        </div>
      </div>
    )
  },
  {
    id: "security",
    title: "Zero-Knowledge Architecture",
    description: "AES-256 encryption with automatic deletion. Your audio never touches our servers permanently. GDPR compliant with audit trails.",
    icon: <Shield className="w-6 h-6" />,
    category: "Security"
  },
  {
    id: "quantum-eq",
    title: "Quantum EQ & Neural Compression",
    description: "64-band spectral shaping with AI-guided curves. Adaptive dynamics processing that learns from vintage hardware characteristics.",
    icon: <Activity className="w-6 h-6" />,
    category: "Audio Tools",
    demo: (
      <div className="grid grid-cols-8 gap-1 h-16">
        {Array.from({ length: 8 }, (_, i) => (
          <div key={i} className="bg-void-green/20 rounded-sm relative">
            <div 
              className="bg-void-green rounded-sm transition-all duration-300"
              style={{ 
                height: `${Math.random() * 80 + 20}%`,
                marginTop: 'auto'
              }}
            ></div>
          </div>
        ))}
      </div>
    )
  },
  {
    id: "voice-control",
    title: "Voice Commands & Gestures",
    description: "\"Increase bass by 2dB\" - Natural language processing for hands-free operation. Trackpad gestures for precise parameter control.",
    icon: <Mic className="w-6 h-6" />,
    category: "Interface",
    badge: "BETA"
  },
  {
    id: "analytics",
    title: "Professional Analytics Suite",
    description: "LUFS monitoring, phase correlation, spectral analysis, and dynamic range measurement. Export reports for broadcast compliance.",
    icon: <Eye className="w-6 h-6" />,
    category: "Analysis"
  },
  {
    id: "api",
    title: "Enterprise API & Integrations",
    description: "RESTful API with webhook automation. Native DAW plugins (VST/AU/AAX) and cloud storage integration (AWS S3, Google Drive).",
    icon: <Globe className="w-6 h-6" />,
    category: "Integration"
  },
  {
    id: "custom-models",
    title: "Custom AI Model Training",
    description: "Train personalized models on your catalog. Label-specific sound signatures and artist-specific mastering preferences.",
    icon: <Cpu className="w-6 h-6" />,
    category: "AI Engine",
    badge: "ENTERPRISE"
  }
];

const categories = ["All", "AI Engine", "Performance", "Workflow", "Security", "Audio Tools", "Interface", "Analysis", "Integration"];

export default function FeatureShowcase() {
  const [selectedCategory, setSelectedCategory] = useState("All");
  const [selectedFeature, setSelectedFeature] = useState<Feature | null>(null);

  const filteredFeatures = selectedCategory === "All" 
    ? features 
    : features.filter(f => f.category === selectedCategory);

  return (
    <section className="py-20 px-6" data-testid="feature-showcase">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-16 animate-fade-in-up">
          <h2 className="text-4xl font-bold text-white mb-4 font-mono">Advanced Neural Capabilities</h2>
          <p className="text-void-gray text-lg max-w-3xl mx-auto">
            Professional-grade mastering powered by proprietary AI models, real-time collaboration, 
            and enterprise security. Built for the future of audio production.
          </p>
        </div>

        {/* Category Filter */}
        <div className="flex flex-wrap gap-2 justify-center mb-12" data-testid="category-filter">
          {categories.map((category) => (
            <Button
              key={category}
              variant={selectedCategory === category ? "default" : "outline"}
              size="sm"
              onClick={() => setSelectedCategory(category)}
              className={`font-mono text-xs ${
                selectedCategory === category 
                  ? 'bg-void-green text-void-dark' 
                  : 'border-void-green/50 text-void-green hover:bg-void-green/10'
              }`}
              data-testid={`filter-${category.toLowerCase().replace(' ', '-')}`}
            >
              {category}
            </Button>
          ))}
        </div>

        {/* Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
          {filteredFeatures.map((feature, index) => (
            <div
              key={feature.id}
              className="glass-panel p-6 cursor-pointer transition-all duration-300 hover:scale-105"
              onClick={() => setSelectedFeature(feature)}
              data-testid={`feature-card-${feature.id}`}
              style={{ animationDelay: `${index * 100}ms` }}
            >
              <div className="flex items-start gap-4 mb-4">
                <div className="text-void-green flex-shrink-0 mt-1">
                  {feature.icon}
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-2">
                    <h3 className="font-bold text-white text-lg">{feature.title}</h3>
                    {feature.badge && (
                      <Badge className="text-xs bg-void-green/20 text-void-green border-void-green/50">
                        {feature.badge}
                      </Badge>
                    )}
                  </div>
                  <div className="text-xs text-void-green/80 mb-3 font-mono">
                    {feature.category}
                  </div>
                </div>
              </div>
              
              <p className="text-void-gray text-sm leading-relaxed mb-4">
                {feature.description}
              </p>
              
              {feature.demo && (
                <div className="mt-4" data-testid={`demo-${feature.id}`}>
                  {feature.demo}
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Feature Detail Modal */}
        {selectedFeature && (
          <div 
            className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4"
            onClick={() => setSelectedFeature(null)}
            data-testid="feature-modal"
          >
            <div 
              className="glass-panel p-8 max-w-2xl w-full max-h-[80vh] overflow-y-auto"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="flex items-start gap-4 mb-6">
                <div className="text-void-green text-2xl">
                  {selectedFeature.icon}
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-2">
                    <h3 className="font-bold text-white text-2xl">{selectedFeature.title}</h3>
                    {selectedFeature.badge && (
                      <Badge className="bg-void-green/20 text-void-green border-void-green/50">
                        {selectedFeature.badge}
                      </Badge>
                    )}
                  </div>
                  <div className="text-void-green/80 font-mono">
                    {selectedFeature.category}
                  </div>
                </div>
              </div>
              
              <p className="text-void-gray leading-relaxed mb-6">
                {selectedFeature.description}
              </p>
              
              {selectedFeature.demo && (
                <div className="mb-6">
                  {selectedFeature.demo}
                </div>
              )}
              
              <Button 
                onClick={() => setSelectedFeature(null)}
                className="btn-primary-voidline"
                data-testid="close-modal"
              >
                Close
              </Button>
            </div>
          </div>
        )}

        {/* CTA Section */}
        <div className="text-center">
          <div className="glass-panel p-8 max-w-4xl mx-auto animate-fade-in-up delay-500">
            <h3 className="text-2xl font-bold text-white mb-4 font-mono">Ready to Experience the Future?</h3>
            <p className="text-void-gray mb-6 max-w-2xl mx-auto">
              Join thousands of producers and engineers already using VoidCore AI to elevate their sound. 
              Start your free trial and master your first track in minutes.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button className="btn-primary-voidline" data-testid="cta-start-trial">
                Start Free Trial
              </Button>
              <Button variant="outline" className="btn-secondary-voidline" data-testid="cta-view-demo">
                View Live Demo
              </Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}