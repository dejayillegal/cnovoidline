import { useEffect, useRef } from "react";
import { useAudioVisualizer } from "@/hooks/use-audio-visualizer";

interface AudioVisualizerProps {
  compact?: boolean;
}

export default function AudioVisualizer({ compact = false }: AudioVisualizerProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const { bars, waveform } = useAudioVisualizer(compact ? 10 : 20);

  const height = compact ? "h-16" : "h-20";

  return (
    <div className="space-y-4" data-testid="audio-visualizer">
      {/* Audio Bars */}
      <div className={`audio-visualizer ${height}`} ref={containerRef} data-testid="audio-bars">
        {bars.map((height, index) => (
          <div
            key={index}
            className="audio-bar"
            style={{ 
              height: `${height}%`,
              animationDelay: `${index * 0.1}s`
            }}
            data-testid={`audio-bar-${index}`}
          />
        ))}
      </div>
      
      {/* Oscilloscope */}
      {!compact && (
        <div className="oscilloscope" data-testid="oscilloscope">
          <div 
            className="waveform" 
            style={{ 
              transform: `translateY(-50%) scaleX(${waveform.scale})`,
              filter: `brightness(${waveform.brightness})`
            }}
            data-testid="waveform"
          />
          <div className="absolute top-2 left-2 text-xs text-void-green font-mono" data-testid="audio-info">
            48kHz | 24-bit | Stereo
          </div>
          <div className="absolute top-2 right-2 text-xs text-void-gray-2 font-mono" data-testid="lufs-reading">
            -12.3 LUFS
          </div>
        </div>
      )}
    </div>
  );
}
