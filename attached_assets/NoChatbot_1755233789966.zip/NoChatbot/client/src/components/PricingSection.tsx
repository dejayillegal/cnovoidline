import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Check, Zap, Rocket, Crown, Star } from "lucide-react";

interface PricingTier {
  name: string;
  price: string;
  period: string;
  description: string;
  features: string[];
  highlighted?: boolean;
  icon: React.ReactNode;
  badge?: string;
}

const pricingTiers: PricingTier[] = [
  {
    name: "Payload",
    price: "Free",
    period: "",
    description: "15 Day Free Trial",
    features: [
      "3 AI Masters / month",
      "Basic AI Presets",
      "48kHz/16-bit Export",
      "Standard Delivery",
      "Community Support"
    ],
    icon: <Zap className="w-5 h-5" />,
  },
  {
    name: "Orbital Pack",
    price: "₹ 599",
    period: "/ month",
    description: "Ideal for EPs and albums, providing better value.",
    features: [
      "15 AI Masters / month",
      "All Formats (WAV, MP3, FLAC)",
      "Priority Queue",
      "Reference Tracks",
      "Advanced Analytics",
      "Email Support"
    ],
    highlighted: true,
    icon: <Rocket className="w-5 h-5" />,
    badge: "MOST POPULAR"
  },
  {
    name: "Voidline Unlimited",
    price: "₹ 999",
    period: "/ year",
    description: "For the prolific producer and professional studios.",
    features: [
      "Unlimited AI Masters",
      "All Formats & Features",
      "Highest Priority Access",
      "Real-time Collaboration",
      "API Access",
      "Custom Model Training",
      "Dedicated Support Channel"
    ],
    icon: <Crown className="w-5 h-5" />,
  }
];

export default function PricingSection() {
  return (
    <section className="py-20 px-6" data-testid="pricing-section">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-16 animate-fade-in-up">
          <div className="flex items-center justify-center gap-2 mb-4">
            <span className="text-void-green text-2xl">$</span>
            <h2 className="text-4xl font-bold text-white font-mono">Transmission Pricing</h2>
          </div>
          <p className="text-void-gray text-lg max-w-2xl mx-auto">
            Choose your mission parameters. Upgrade for enhanced processing power and advanced neural capabilities.
          </p>
        </div>

        {/* Pricing Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
          {pricingTiers.map((tier, index) => (
            <div
              key={tier.name}
              className={`pricing-card relative ${tier.highlighted ? 'featured' : ''}`}
              data-testid={`pricing-card-${tier.name.toLowerCase().replace(' ', '-')}`}
              style={{ animationDelay: `${index * 100}ms` }}
            >
              {tier.badge && (
                <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                  <Badge className="bg-void-green text-void-dark font-bold px-3 py-1">
                    <Star className="w-3 h-3 mr-1" />
                    {tier.badge}
                  </Badge>
                </div>
              )}
              
              <div className="text-center mb-8">
                <div className="flex items-center justify-center gap-2 mb-4">
                  <div className="text-void-green">{tier.icon}</div>
                  <h3 className="text-2xl font-bold text-white font-mono">{tier.name}</h3>
                </div>
                
                <div className="mb-4">
                  <span className="text-4xl font-bold text-void-green font-mono">{tier.price}</span>
                  {tier.period && (
                    <span className="text-void-gray-2 ml-2">{tier.period}</span>
                  )}
                </div>
                
                <p className="text-void-gray-2 text-sm">{tier.description}</p>
              </div>

              <div className="space-y-4 mb-8">
                {tier.features.map((feature, featureIndex) => (
                  <div 
                    key={featureIndex}
                    className="flex items-start gap-3"
                    data-testid={`feature-${featureIndex}`}
                  >
                    <Check className="w-4 h-4 text-void-green mt-0.5 flex-shrink-0" />
                    <span className="text-void-gray text-sm">{feature}</span>
                  </div>
                ))}
              </div>

              <Button
                className={`w-full ${
                  tier.highlighted 
                    ? 'btn-primary-voidline' 
                    : 'btn-secondary-voidline'
                }`}
                data-testid={`button-select-${tier.name.toLowerCase().replace(' ', '-')}`}
              >
                {tier.name === "Payload" ? "Start Trial" : "Select Plan"}
              </Button>
            </div>
          ))}
        </div>

        {/* Enterprise Section */}
        <div className="text-center">
          <div className="glass-panel p-8 max-w-4xl mx-auto animate-fade-in-up delay-300">
            <h3 className="text-2xl font-bold text-white mb-4 font-mono">Enterprise & Custom Solutions</h3>
            <p className="text-void-gray mb-6 max-w-2xl mx-auto">
              Need white-label deployment, custom AI training, or dedicated infrastructure? 
              Our enterprise solutions scale with your organization's requirements.
            </p>
            
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8 text-sm">
              <div className="text-center">
                <div className="text-void-green font-bold mb-1">Custom Deployment</div>
                <div className="text-void-gray-2">On-premise or private cloud</div>
              </div>
              <div className="text-center">
                <div className="text-void-green font-bold mb-1">White-Label UI</div>
                <div className="text-void-gray-2">Your brand, our technology</div>
              </div>
              <div className="text-center">
                <div className="text-void-green font-bold mb-1">Custom AI Models</div>
                <div className="text-void-gray-2">Trained on your catalog</div>
              </div>
              <div className="text-center">
                <div className="text-void-green font-bold mb-1">SLA Guarantees</div>
                <div className="text-void-gray-2">99.9% uptime commitment</div>
              </div>
            </div>
            
            <Button variant="outline" className="btn-secondary-voidline" data-testid="button-enterprise">
              Contact Enterprise Sales
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
}